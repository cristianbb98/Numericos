<?php
echo "works";